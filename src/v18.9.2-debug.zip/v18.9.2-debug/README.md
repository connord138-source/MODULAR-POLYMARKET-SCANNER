# Polymarket Scanner v18.9.0 - Winning Focus

## 🎯 GOAL: Identify winning wallets and winning patterns with high probability

This version fundamentally changes the approach:
- **Track WINNERS, not everyone** - Only persist wallets with 55%+ win rate
- **Prune LOSERS** - Auto-delete wallets with <45% after 5+ bets
- **Sports Priority** - Top 15 sports props always available
- **Memory Optimized** - No more memory limit crashes

---

## What's New

### 1. Winner-Focused Wallet Tracking

| Before | After |
|--------|-------|
| Track ALL 978 wallets | Only track wallets with potential |
| Keep losers forever | Auto-prune <45% win rate |
| Flat confidence | Winning wallet = +10-15% confidence boost |

### 2. Sports Props Priority

New endpoint: `/scan/sports/top15`
- Returns top 15 sports signals
- Prioritizes signals with winning wallets
- Filters for 65%+ confidence

### 3. KV Cleanup

**What we KEEP (the brain):**
- `factor_stats_v2` - AI learning (win rates per factor)
- `market_type_stats` - Which markets win
- `volume_brackets` - Which volumes win
- `time_patterns` - When signals win
- `winning_wallets_cache` - Fast lookup of proven winners
- `pending_signals_v2` - Signals awaiting settlement

**What we DELETE:**
- `trades_bucket_*` - 43 hourly buckets (not needed, use API)
- Losing wallets (<45% after 5+ bets)

---

## New Endpoints

### Cleanup Endpoints (POST, require auth)

```bash
# Prune losing wallets only
curl -X POST https://your-worker/admin/prune-losers \
  -H "Authorization: Bearer polymarket-admin-2026"

# Clear trade buckets only
curl -X POST https://your-worker/admin/clear-buckets \
  -H "Authorization: Bearer polymarket-admin-2026"

# Full cleanup (both)
curl -X POST https://your-worker/admin/full-cleanup \
  -H "Authorization: Bearer polymarket-admin-2026"
```

### Sports Priority Endpoint

```bash
# Get top 15 sports props with winning wallet info
curl https://your-worker/scan/sports/top15
```

Response:
```json
{
  "success": true,
  "signals": [...],  // Top 15 sports signals
  "totalSportsSignals": 47,
  "signalsWithWinners": 5,
  "avgConfidence": 68
}
```

---

## How Winning Wallets Work Now

### Signal Detection
1. Scan finds whale activity
2. Check each wallet against `winning_wallets_cache`
3. If wallet has 55%+ win rate:
   - `hasWinningWallet: true`
   - `winningWalletInfo: { winRate, record, tier }`
   - Confidence boosted by 10-15%
   - `winningWallet` factor added to scoreBreakdown

### Wallet Lifecycle
```
New bet detected
    ↓
Track in KV (pending)
    ↓
Signal settles (WIN/LOSS)
    ↓
Update wallet stats
    ↓
Evaluate: Keep or Prune?
    ↓
If winner (55%+): Add to winning_wallets_cache
If loser (45%- after 5+ bets): DELETE from KV
```

### Winning Wallet Boost
```javascript
// A wallet with 70% win rate adds:
walletBoost = min(15, (70 - 50) / 3) = 6.7% confidence

// A wallet with 80% win rate adds:
walletBoost = min(15, (80 - 50) / 3) = 10% confidence

// Capped at 15% max boost
```

---

## Deploy Instructions

1. **Deploy the code:**
```bash
cp -r v18.9.0-winning-focus/* your-worker/src/
cd your-worker
npx wrangler deploy
```

2. **Run initial cleanup (IMPORTANT):**
```bash
# This clears trade buckets and prunes losers
curl -X POST https://polymarket-scanner.connord138.workers.dev/admin/full-cleanup \
  -H "Authorization: Bearer polymarket-admin-2026"
```

3. **Verify:**
```bash
curl https://polymarket-scanner.connord138.workers.dev/health
# Should show version 18.9.0

curl https://polymarket-scanner.connord138.workers.dev/scan/sports/top15
# Should return top sports signals
```

---

## Expected Results

### After Deploy + Cleanup:
- Memory errors gone (no more 43 bucket loads)
- Faster scans (direct API, no KV bucket assembly)
- Leaderboard shows only promising wallets

### After 24-48 Hours:
- `winning_wallets_cache` populates with proven winners
- Signals with winning wallets show confidence boost
- Losers auto-pruned from system

### After 1 Week:
- Clear picture of which wallets to follow
- AI learning refined to your specific markets
- High-confidence sports picks available

---

## Files Changed

| File | Changes |
|------|---------|
| `signals.js` | Winner detection, sports priority, memory optimization |
| `wallets.js` | Auto-prune, winner cache, cleanup functions |
| `index.js` | New endpoints: cleanup, sports/top15 |
| `config.js` | Version 18.9.0 |
